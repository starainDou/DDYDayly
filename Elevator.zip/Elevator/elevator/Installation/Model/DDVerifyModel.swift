//
//  DDVerifyModel.swift
//  elevator
//
//  Created by ddy on 2023/1/29.
//

import Foundation

class DDVerifyModel: NSObject {
    var title: String = ""
    var state: String = ""
    var time: String = ""
}
