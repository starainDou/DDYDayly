//
//  DDMainteDetail3Cell.swift
//  elevator
//
//  Created by ddy on 2023/2/5.
//

import UIKit

class DDMainteDetail3Cell: UITableViewCell {

    

}
