//
//  DDMainteDetail3ItemCell.swift
//  elevator
//
//  Created by ddy on 2023/2/5.
//

import UIKit

class DDMainteDetail3ItemCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
